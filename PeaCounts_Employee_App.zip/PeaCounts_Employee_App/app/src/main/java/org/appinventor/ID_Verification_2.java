/** This is the second screen of verification process
 * Camera will be used here to take selfie
 * then selfie will need to be compared against picture
 * from ID_Verification_1 using facial recognition
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Camera;
class ID_Verification_2 extends Form implements HandlesEventDispatching {
  private Camera Camera1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Take Selfie to Verify ID");
    Camera1 = new Camera(this);
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}