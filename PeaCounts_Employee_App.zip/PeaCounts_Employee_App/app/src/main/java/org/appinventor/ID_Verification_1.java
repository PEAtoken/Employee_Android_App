/** This is the first screen of the verification process
 * On this screen a photo will be taken of photo ID to use
 * on ID_Verification_2 to compare with selfie to identify user
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Camera;
import com.google.appinventor.components.runtime.TinyDB;
import com.google.appinventor.components.runtime.Notifier;
class ID_Verification_1 extends Form implements HandlesEventDispatching {
  private Camera Camera1;
  private TinyDB TinyDB1;
  private Notifier Notifier1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Please Take Pic of Photo ID");
    Camera1 = new Camera(this);
    TinyDB1 = new TinyDB(this);
    Notifier1 = new Notifier(this);
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}