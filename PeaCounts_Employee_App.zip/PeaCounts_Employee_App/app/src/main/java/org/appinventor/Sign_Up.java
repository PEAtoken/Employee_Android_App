/** This is a very simple sign-up, we may need more fields in the future
 * but wanted to keep it simple for the MVP access.
 * The Terms and Conditions could either be a popup or linked to T_and_C
 * screen to read terms there.
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.CheckBox;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Notifier;
class Sign_Up extends Form implements HandlesEventDispatching {
  private Image Image1;
  private HorizontalArrangement HorizontalArrangement1;
  private Label Label3;
  private TextBox UserTxt1;
  private HorizontalArrangement HorizontalArrangement2;
  private Label Label2;
  private TextBox UserTxt2;
  private HorizontalArrangement HorizontalArrangement3;
  private Label Label4;
  private TextBox PassTxt1;
  private HorizontalArrangement HorizontalArrangement4;
  private Label Label5;
  private TextBox PassTxt2;
  private HorizontalArrangement HorizontalArrangement5;
  private CheckBox CheckBox1;
  private Button Reg;
  private Label Label1;
  private Notifier Notifier1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Sign_Up");
    Image1 = new Image(this);
    Image1.Width(LENGTH_FILL_PARENT);
    Image1.Picture("PeaCountsLogo.png");
    Image1.Visible(false);
    HorizontalArrangement1 = new HorizontalArrangement(this);
    Label3 = new Label(HorizontalArrangement1);
    Label3.Text("Email Address");
    UserTxt1 = new TextBox(HorizontalArrangement1);
    UserTxt1.Hint("First Name");
    HorizontalArrangement2 = new HorizontalArrangement(this);
    Label2 = new Label(HorizontalArrangement2);
    Label2.Text("Confirm Email");
    UserTxt2 = new TextBox(HorizontalArrangement2);
    UserTxt2.Hint("Phone Number");
    HorizontalArrangement3 = new HorizontalArrangement(this);
    Label4 = new Label(HorizontalArrangement3);
    Label4.Text("Password");
    PassTxt1 = new TextBox(HorizontalArrangement3);
    PassTxt1.Hint("Email Address");
    HorizontalArrangement4 = new HorizontalArrangement(this);
    Label5 = new Label(HorizontalArrangement4);
    Label5.Text("Confirm Password");
    PassTxt2 = new TextBox(HorizontalArrangement4);
    PassTxt2.Hint("Last Name");
    HorizontalArrangement5 = new HorizontalArrangement(this);
    CheckBox1 = new CheckBox(HorizontalArrangement5);
    CheckBox1.Text(" I agree to the terms and conditions of use (click for more info)");
    Reg = new Button(this);
    Reg.Text("Register");
    Label1 = new Label(this);
    Notifier1 = new Notifier(this);
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(Reg) && eventName.equals("Click") ){
      RegClick();
      return true;
    }
    return false;
  }
  public void RegClick(){
    if(UserTxt1.Text().equals(UserTxt2.Text()) && PassTxt1.Text().equals(PassTxt2.Text()) && true == CheckBox1.Checked()){
    }
    else {
    }
  }
}