/** This is the home screen. It will need to show the job offer
 * that is accessed based on the email address of the employee.
 * Maybe if job offer doesn't show we need a button where employee
 * could add a second email address to tie to their account, in case
 * the job offer was sent to a different email?
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Notifier;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;
class Home extends Form implements HandlesEventDispatching {
  private Image Image1;
  private HorizontalArrangement HorizontalArrangement1;
  private Label Label1;
  private HorizontalArrangement HorizontalArrangement2;
  private Button Button1;
  private Notifier Notifier1;
  private boolean edit_state;
  private String user;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Home");
    Image1 = new Image(this);
    Image1.Width(LENGTH_FILL_PARENT);
    Image1.Picture("PeaCountsLogo.png");
    HorizontalArrangement1 = new HorizontalArrangement(this);
    Label1 = new Label(HorizontalArrangement1);
    Label1.Text("Your Jobs:");
    HorizontalArrangement2 = new HorizontalArrangement(this);
    Button1 = new Button(HorizontalArrangement2);
    Notifier1 = new Notifier(this);
    edit_state = false;
    user = "";
    EventDispatcher.registerEventForDelegation(this, "InitializeEvent", "Initialize" );
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(this) && eventName.equals("Initialize") ){
      thisInitialize();
      return true;
    }
    if( component.equals(Button1) && eventName.equals("Click") ){
      Button1Click();
      return true;
    }
    return false;
  }
  public void thisInitialize(){
    user = (String) ((List)getIntent().getExtras().get("startValue")).get(1 - 1);
    Button1.Text(String.valueOf(((List)getIntent().getExtras().get("startValue")).get(2 - 1)));
  }
  public void Button1Click(){
    startActivity(new Intent().setClass(this, Job_Offer.class));
  }
}