/** This screen is where the work agreed on by the smart contract terms
 * will be monitored and determined to meet the terms of agreement
 * Will need a start work and end work button as well, but I didn't add
 * this as I wasn't sure how to tie it all together for the data tree.
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.ActivityStarter;
import com.google.appinventor.components.runtime.AccelerometerSensor;
import com.google.appinventor.components.runtime.Clock;
import com.google.appinventor.components.runtime.LocationSensor;
import com.google.appinventor.components.runtime.Pedometer;
class Start_work extends Form implements HandlesEventDispatching {
  private Image Image1;
  private ActivityStarter ActivityStarter1;
  private AccelerometerSensor AccelerometerSensor1;
  private Clock Clock1;
  private LocationSensor LocationSensor1;
  private Pedometer Pedometer1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("You Are Working Now. ");
    Image1 = new Image(this);
    ActivityStarter1 = new ActivityStarter(this);
    AccelerometerSensor1 = new AccelerometerSensor(this);
    Clock1 = new Clock(this);
    LocationSensor1 = new LocationSensor(this);
    Pedometer1 = new Pedometer(this);
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}