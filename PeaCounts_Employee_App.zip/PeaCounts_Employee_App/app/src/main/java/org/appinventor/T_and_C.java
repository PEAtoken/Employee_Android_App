/** This screen was added in case we need a separate terms and conditions
 * screen, but then I thought this may be better served by adding this info
 * as a popup on the Sign_Up screen. We may want it separate though so we can
 * direct users here to sign again if there are changes, thoughts?
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ListView;
import com.google.appinventor.components.runtime.CheckBox;
class T_and_C extends Form implements HandlesEventDispatching {
  private ListView ListView1;
  private CheckBox CheckBox1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Terms and Conditions of Use");
    ListView1 = new ListView(this);
    ListView1.ElementsFromString("use of the peacounts payroll system is at your own risk and anything you put in here is datea we may use under GDPR");
    CheckBox1 = new CheckBox(this);
    CheckBox1.Text("  I Agree");
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}