/** This is the login screen. I added all the data tie-ins here on TinyDB
 * rather than on the Sign_Up screen to try and keep it simple.
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TableArrangement;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.PasswordTextBox;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.CheckBox;
import com.google.appinventor.components.runtime.TinyDB;
import java.util.ArrayList;
import java.util.List;
class Screen1 extends Form implements HandlesEventDispatching {
  private Image Image1;
  private Label Label1;
  private Label Label2;
  private TableArrangement TableArrangement1;
  private TextBox TextBox1;
  private PasswordTextBox PasswordTextBox2;
  private Label Label3;
  private Label Label4;
  private Button Login;
  private CheckBox CheckBox1;
  private Button Create_Account;
  private Label Label5;
  private TinyDB TinyDB1;
  private String user;
  private String pass;
  protected void $define() {
    this.AboutScreen("Login");
    this.AppName("PeaCountsPrototype");
    this.Title("Login");
    Image1 = new Image(this);
    Image1.Width(LENGTH_FILL_PARENT);
    Image1.Picture("PeaCountsLogo.png");
    Label1 = new Label(this);
    Label1.Text("Welcome to PeaCounts Payroll.");
    Label2 = new Label(this);
    Label2.Text(" Please sign in below to access your account. ");
    TableArrangement1 = new TableArrangement(this);
    TextBox1 = new TextBox(TableArrangement1);
    TextBox1.Column(1);
    TextBox1.Hint("Hint for TextBox1");
    TextBox1.Row(0);
    PasswordTextBox2 = new PasswordTextBox(TableArrangement1);
    PasswordTextBox2.Column(1);
    PasswordTextBox2.Row(1);
    Label3 = new Label(TableArrangement1);
    Label3.Column(0);
    Label3.Row(0);
    Label3.Text("Username");
    Label4 = new Label(TableArrangement1);
    Label4.Column(0);
    Label4.Row(1);
    Label4.Text("Password");
    Login = new Button(this);
    Login.Text("Login");
    CheckBox1 = new CheckBox(this);
    CheckBox1.Text("   Save Username");
    Create_Account = new Button(this);
    Create_Account.Text("Create Account");
    Label5 = new Label(this);
    TinyDB1 = new TinyDB(this);
    user = "";
    pass = "";
    EventDispatcher.registerEventForDelegation(this, "OtherScreenClosedEvent", "OtherScreenClosed" );
    EventDispatcher.registerEventForDelegation(this, "InitializeEvent", "Initialize" );
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(this) && eventName.equals("OtherScreenClosed") ){
      thisOtherScreenClosed((String)params[0], (Object)params[1]);
      return true;
    }
    if( component.equals(this) && eventName.equals("Initialize") ){
      thisInitialize();
      return true;
    }
    if( component.equals(Login) && eventName.equals("Click") ){
      LoginClick();
      return true;
    }
    return false;
  }
  public void thisOtherScreenClosed(String otherScreenName, Object result){
    if(otherScreenName.equals("Sign_Up")){
      TinyDB1.StoreValue(((List)1).get(result - 1), "user" + ((List)result).get(1 - 1) + ((List)result).get(2 - 1));
      TinyDB1.StoreValue(((List)result).get(2 - 1), ((List)result).get(2 - 1) + ((List)result).get(1 - 1) + "pass");
    }
    else if(otherScreenName.equals("home") && ((result) instanceof ArrayList<?>)){
      TinyDB1.StoreValue(((List)result).get(2 - 1) + "jobs", ((List)result).get(1 - 1));
    }
  }
  public void thisInitialize(){
    if(TinyDB1.GetValue("", "C").equals("checked")){
      CheckBox1.Checked(true);
      TextBox1.Text(String.valueOf(TinyDB1.GetValue("U", "")));
    }
  }
  public void LoginClick(){
    if(CheckBox1.Checked() == true){
      TinyDB1.StoreValue("U", TextBox1.Text());
      TinyDB1.StoreValue("C", "clicked");
    }
    else {
      TinyDB1.StoreValue("C", "not");
    }
    user = (String) TinyDB1.GetValue("", TextBox1.Text());
    pass = (String) TinyDB1.GetValue("", PasswordTextBox2.Text());
    if(user.equals(TextBox1.Text() + PasswordTextBox2.Text() + "user") && pass.equals(PasswordTextBox2.Text() + TextBox1.Text() + "pass")){
      Label5.Text("Incorrect Login");
    }
  }
}