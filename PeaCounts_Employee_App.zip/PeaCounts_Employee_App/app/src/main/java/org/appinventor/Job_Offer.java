/** This screen will be used to show the job offer and
 * send the worker to the verification process if not yet
 * verified and if verified send them to the smart contract
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Notifier;
import android.content.Intent;
class Job_Offer extends Form implements HandlesEventDispatching {
  private Label Label1;
  private HorizontalArrangement HorizontalArrangement1;
  private Label Label2;
  private HorizontalArrangement HorizontalArrangement2;
  private Button Button1;
  private Notifier Notifier1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Job Offer");
    Label1 = new Label(this);
    Label1.Text("Congratulations on your job offer!");
    HorizontalArrangement1 = new HorizontalArrangement(this);
    Label2 = new Label(HorizontalArrangement1);
    HorizontalArrangement2 = new HorizontalArrangement(this);
    Button1 = new Button(HorizontalArrangement2);
    Button1.Text("Accept Job");
    Notifier1 = new Notifier(this);
    EventDispatcher.registerEventForDelegation(this, "InitializeEvent", "Initialize" );
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(this) && eventName.equals("Initialize") ){
      thisInitialize();
      return true;
    }
    if( component.equals(Button1) && eventName.equals("Click") ){
      Button1Click();
      return true;
    }
    return false;
  }
  public void thisInitialize(){
    Label1.Text("Job Offer");
  }
  public void Button1Click(){
    if("verified".equals("verified")){
      startActivity(new Intent().setClass(this, Smart_Contract_1.class));
    }
    else {
      startActivity(new Intent().setClass(this, ID_Verification_1.class));
    }
  }
}