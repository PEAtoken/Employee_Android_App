/** This is the third screen of the verification process
 * On this screen a photo of the tax ID card will be taken and then
 * this information will need OCR scanning to break it down to add
 * automatically to the tax and hiring forms.
 * Possibly a manual typing of numbers should be added as an option?
 * After verification user will be sent to the Smart_Contract_1 screen
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.Camera;
class ID_Veriification_3 extends Form implements HandlesEventDispatching {
  private Camera Camera1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Take Photo of Tax ID Card");
    Camera1 = new Camera(this);
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    return false;
  }
}