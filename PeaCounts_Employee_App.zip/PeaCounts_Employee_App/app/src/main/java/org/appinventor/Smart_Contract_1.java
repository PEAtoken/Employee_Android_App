/** This screen will need to show the smart contract terms and walk the
 * employee through the process of agreeing to each term.
 * After agreement the user will be sent to the Start_work screen
 */
package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ListView;
import com.google.appinventor.components.runtime.CheckBox;
import com.google.appinventor.components.runtime.ListPicker;
import com.google.appinventor.components.runtime.Button;
import android.content.Intent;
class Smart_Contract_1 extends Form implements HandlesEventDispatching {
  private ListView ListView1;
  private CheckBox CheckBox1;
  private ListPicker ListPicker1;
  private ListView ListView2;
  private CheckBox CheckBox2;
  private ListPicker ListPicker2;
  private Button Button1;
  protected void $define() {
    this.AppName("PeaCountsPrototype");
    this.Title("Smart Contract Agreement");
    ListView1 = new ListView(this);
    ListView1.ElementsFromString("Your employer is requesting that you share your geolocation with them during the work engagement so they can track that you remain near the job site.  Please click I agree below to show you agree to these employment terms. ");
    CheckBox1 = new CheckBox(this);
    CheckBox1.Text(" I Agree");
    ListPicker1 = new ListPicker(this);
    ListPicker1.ElementsFromString("Your location will only be tracked while you are working. Once you end the work engagement then location monitoring will automatically turn off.  ");
    ListPicker1.Text("More Information");
    ListPicker1.Title("More Information");
    ListView2 = new ListView(this);
    ListView2.ElementsFromString("Your employer is requesting that you allow your activity to be monitored by the App during your employment. Please click the button below to agree to this condition of employment. ");
    CheckBox2 = new CheckBox(this);
    CheckBox2.Text("  I Agree");
    ListPicker2 = new ListPicker(this);
    ListPicker2.ElementsFromString("Your motion will only be tracked while you are working. Once you end the work engagement then activity monitoring will automatically turn off.  ");
    ListPicker2.Text("More Information");
    ListPicker2.Title("More Information");
    Button1 = new Button(this);
    Button1.Text("Start Work");
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(Button1) && eventName.equals("Click") ){
      Button1Click();
      return true;
    }
    return false;
  }
  public void Button1Click(){
    if(CheckBox1.Checked() == true && CheckBox2.Checked() == true){
      startActivity(new Intent().setClass(this, Start_Work.class));
    }
  }
}